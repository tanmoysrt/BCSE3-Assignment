sn = 0
snmax = 3
N = 4


while True:
    print(sn)
    sn = (sn+1)%snmax