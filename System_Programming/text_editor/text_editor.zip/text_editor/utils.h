#ifndef UTILS_H
#define UTILS_H

class Utils{


}

#endif // UTILS_H
